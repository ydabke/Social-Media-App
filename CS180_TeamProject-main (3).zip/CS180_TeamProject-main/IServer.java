/**
 * Interface for the Chat class
 */
public interface IServer {
    /* There is nothing in this interface, since Server
     * only has a public void run() method from Runnable,
     * and a main method.
     */   
}
